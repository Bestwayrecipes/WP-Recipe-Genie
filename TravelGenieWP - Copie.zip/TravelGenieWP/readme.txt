=== Travel Genie WP ===
Contributors: tunisiaexplorer  
Donate link: https://tunisiaexplorer.com/Travel  
Tags: travel, trip planner, travel blog, itinerary, travel guide, seo  
Requires at least: 5.0  
Tested up to: 6.8  
Stable tag: 1.0.0  
Requires PHP: 7.4  
Plugin Icon: assets/icon-256x256.png  
License: GPLv2 or later  
License URI: https://www.gnu.org/licenses/gpl-2.0.html  

A beginner-friendly WordPress plugin for travel bloggers to create SEO-optimized travel articles. Streamlines trip content creation and boosts search visibility.

== Description ==

**Travel Genie WP** is a simple, beginner-friendly WordPress plugin that helps travel bloggers and content creators generate SEO-optimized travel posts with focus keywords, related keywords, internal and external links, and destination images. It streamlines travel article creation while improving visibility on search engines like Google and Bing.

Whether you're sharing itineraries, city guides, or destination reviews, Travel Genie WP helps you build high-performing, beautiful blog posts in minutes.

== Features ==

* Easy-to-use travel article editor for all skill levels
* SEO-focused fields including:
  * Focus keyword
  * Related keywords
  * Internal and external link embedding
* Upload and embed travel images seamlessly
* Automatically adds Schema.org structured data (JSON-LD) for travel-related content
* Clean front-end layout compatible with most WordPress themes
* Ideal for travel bloggers, influencers, and niche travel websites

== Installation ==

1. Upload the `travel-genie-wp` plugin folder to the `/wp-content/plugins/` directory via FTP, or upload the plugin ZIP file through 'Plugins > Add New > Upload Plugin' in your WordPress admin area.  
2. Activate **Travel Genie WP** via the 'Plugins' menu in WordPress.  
3. Once activated, look for "Travel Genie WP" in the WordPress admin menu. Click it to begin creating your travel articles.

== Frequently Asked Questions ==

= How do I create a new travel article? =  
After activation, go to "Travel Genie WP" in your WordPress admin sidebar. Click "Add New Article" to open the editor. Fill in your destination title, itinerary details, keywords, descriptions, links, and images.

= Is this plugin compatible with all WordPress themes? =  
Yes, Travel Genie WP works with most well-coded WordPress themes. If you run into display issues, visit our support at [https://tunisiaexplorer.com/support](https://tunisiaexplorer.com/support).

= Does this plugin support Schema.org markup for SEO? =  
Yes. The plugin automatically adds JSON-LD structured data to improve your chances of appearing in Google's rich snippets and featured results.

= What's the difference between focus and related keywords? =  
Focus keywords are the primary terms you want to rank for (e.g., "Paris itinerary"). Related keywords are supporting terms (e.g., "Eiffel Tower tips", "best cafes in Paris") that help search engines understand context.

== Screenshots ==

1. Travel Genie WP admin menu in dashboard  
2. Travel article editing interface  
3. Front-end example of a travel post  
4. SEO settings available for each article  

== Changelog ==

= 1.0.0 - 2025-05-28 =  
* Initial release of Travel Genie WP  
* Core features: travel article creation, focus/related SEO fields, internal/external links, image uploads, Schema.org support  

== Upgrade Notice ==

= 1.0.0 =  
Thanks for installing Travel Genie WP! This first release includes all the essentials you need to create stunning, SEO-optimized travel content.

== About the Author ==

**Travel Genie WP** is developed and maintained by [TunisiaExplorer](https://tunisiaexplorer.com), a platform dedicated to smart tools and content automation for travel bloggers and creators.  
Plugin URI: https://www.tunisiaexplorer.com/Travel  
Author URI: https://www.tunisiaexplorer.com

