<?php
/**
 * Plugin Name:       Travel Genie WP
 * Plugin URI:        https://www.tunisiaexplorer.com/Travel
 * Description:       Travel Genie WP is a powerful WordPress plugin that helps travel bloggers create SEO-optimized travel articles with focus keywords, related keywords, internal and external links, and images. It streamlines travel content creation while improving search engine visibility.
 * Version:           1.0.0
 * Author:            TunisiaExplorer
 * Author URI:        https://www.tunisiaexplorer.com
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       travel-genie-wp
 * Domain Path:       /languages
 */

// Define version constant if not already defined by another process
if ( ! defined( 'TRAVEL_GENERATOR_VERSION' ) ) {
    define( 'TRAVEL_GENERATOR_VERSION', '1.0.0' ); // Default version
}

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

define( 'TRAVEL_GENERATOR_PATH', plugin_dir_path( __FILE__ ) );
define( 'TRAVEL_GENERATOR_URL', plugin_dir_url( __FILE__ ) );

/**
 * Initialize plugin functionality.
 */
function travel_generator_init() {
    // Register block
    add_action( 'init', 'travel_generator_register_block' );

    // Register shortcode
    add_shortcode( 'travel_generator', 'travel_generator_render_shortcode' );

    // Load plugin textdomain for translation
    load_plugin_textdomain( 'travel-genie-wp', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'plugins_loaded', 'travel_generator_init' );

/**
 * Add admin menu for settings page.
 */
function travel_generator_admin_menu() {
    // Add top-level menu page
    add_menu_page(
        __( 'Travel Generator', 'travel-genie-wp' ), // Page title
        __( 'Travel Generator', 'travel-genie-wp' ), // Menu title
        'manage_options',                             // Capability
        'travel-generator-main',                      // Menu slug
        'travel_generator_page_generate_article_html', // Function to display first page (Generate Article)
        'dashicons-palmtree',                         // Icon URL
        62                                            // Position
    );

    // Add submenu page for "Generate Article" (this will also be the default page for the top-level menu)
    add_submenu_page(
        'travel-generator-main',                      // Parent slug
        __( 'Generate Article', 'travel-genie-wp' ),  // Page title
        __( 'Generate Article', 'travel-genie-wp' ),  // Menu title
        'manage_options',                             // Capability
        'travel-generator-main',                      // Menu slug (same as parent to make it the default)
        'travel_generator_page_generate_article_html'  // Function
    );

    // Add submenu page for "Generated Articles"
    add_submenu_page(
        'travel-generator-main',                         // Parent slug
        __( 'Generated Articles', 'travel-genie-wp' ),   // Page title
        __( 'Generated Articles', 'travel-genie-wp' ),   // Menu title
        'manage_options',                                // Capability
        'travel-generator-view-generated',               // Menu slug
        'travel_generator_page_generated_articles_html' // Function
    );

    // Add submenu page for "Settings"
    add_submenu_page(
        'travel-generator-main',                         // Parent slug
        __( 'Travel Generator Settings', 'travel-genie-wp' ), // Page title
        __( 'Settings', 'travel-genie-wp' ),            // Menu title
        'manage_options',                                // Capability
        'travel-generator-settings',                     // Menu slug (use the existing one for settings)
        'travel_generator_settings_page_html'            // Function (existing settings page function)
    );

    // Add Help submenu page
    add_submenu_page(
        'travel-generator-main', // Parent slug
        __( 'Help', 'travel-genie-wp' ), // Page title
        __( 'Help', 'travel-genie-wp' ), // Menu title
        'manage_options', // Capability
        'travel-generator-help', // Menu slug
        'travel_generator_page_help_html' // Callback function
    );
}
add_action( 'admin_menu', 'travel_generator_admin_menu' );

/**
 * Add Settings and Help links to the plugin action links.
 *
 * @param array $links An array of plugin action links.
 * @return array An array of plugin action links.
 */
function travel_genie_add_plugin_action_links( $links ) {
    $settings_page_url = admin_url( 'admin.php?page=travel-generator-settings' );
    $help_page_url = admin_url( 'admin.php?page=travel-generator-help' );

    $settings_link = '<a href="' . esc_url( $settings_page_url ) . '">' . esc_html__( 'Settings', 'travel-genie-wp' ) . '</a>';
    $help_link = '<a href="' . esc_url( $help_page_url ) . '">' . esc_html__( 'Help', 'travel-genie-wp' ) . '</a>';

    // Create an array for the new links to ensure order
    $custom_links = array(
        'settings' => $settings_link,
        'help'     => $help_link,
    );

    // Determine the key to insert after ('deactivate' or 'activate')
    $action_key_to_insert_after = '';
    if ( isset( $links['deactivate'] ) ) {
        $action_key_to_insert_after = 'deactivate';
    } elseif ( isset( $links['activate'] ) ) {
        $action_key_to_insert_after = 'activate';
    }

    if ( ! empty( $action_key_to_insert_after ) ) {
        $new_links_array = array();
        foreach ( $links as $key => $link ) {
            $new_links_array[ $key ] = $link;
            if ( $key === $action_key_to_insert_after ) {
                // Insert custom links after the identified action key
                foreach ( $custom_links as $custom_key => $custom_link_html ) {
                    $new_links_array[ $custom_key ] = $custom_link_html;
                }
            }
        }
        return $new_links_array;
    }

    // Fallback: if neither activate nor deactivate is found, merge (prepends custom links by default)
    return array_merge( $custom_links, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'travel_genie_add_plugin_action_links' );

// Ensure WP_List_Table class is available
if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

/**
 * Class Travel_Generator_Generated_Articles_List_Table
 * Handles the display of generated articles in a WP_List_Table.
 */
class Travel_Generator_Generated_Articles_List_Table extends WP_List_Table {

    public function __construct() {
        parent::__construct( [
            'singular' => __( 'Generated Article', 'travel-genie-wp' ), // singular name of the listed records
            'plural'   => __( 'Generated Articles', 'travel-genie-wp' ), // plural name of the listed records
            'ajax'     => false // does this table support ajax?
        ] );
    }

    public function get_columns() {
        $columns = [
            'cb'        => '<input type="checkbox" />',
            'title'     => __( 'Title', 'travel-genie-wp' ),
            'focus_keyword' => __( 'Focus Keyword', 'travel-genie-wp' ),
            'date'      => __( 'Date Created', 'travel-genie-wp' ),
        ];
        return $columns;
    }

    public function prepare_items() {
        $columns = $this->get_columns();
        $hidden = [];
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = [$columns, $hidden, $sortable];

        $per_page = $this->get_items_per_page( 'articles_per_page', 20 );
        $current_page = $this->get_pagenum();

        $query_args = [
            'post_type'      => 'post',
            'posts_per_page' => $per_page,
            'paged'          => $current_page,
            'post_status'    => ['draft', 'publish', 'pending', 'future', 'private'], // Include various statuses
            'meta_query'     => [
                [
                    'key'     => '_travel_generator_ai_article',
                    'value'   => true,
                    'compare' => '=',
                ]
            ]
        ];
        
        // Add sorting
        $orderby = ( isset( $_GET['orderby'] ) && in_array( $_GET['orderby'], array_keys( $this->get_sortable_columns() ) ) ) ? $_GET['orderby'] : 'date';
        $order = ( isset( $_GET['order'] ) && in_array( strtoupper( $_GET['order'] ), ['ASC', 'DESC'] ) ) ? $_GET['order'] : 'DESC';
        $query_args['orderby'] = $orderby;
        $query_args['order'] = $order;

        $query = new WP_Query( $query_args );

        $this->items = $query->get_posts();
        $total_items = $query->found_posts;

        $this->set_pagination_args( [
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil( $total_items / $per_page )
        ] );
    }

    protected function get_sortable_columns() {
        $sortable_columns = [
            'title' => ['title', false], // true for initial sort, false otherwise
            'date'  => ['date', true]    // Sort by date by default
        ];
        return $sortable_columns;
    }

    protected function column_default( $item, $column_name ) {
        switch ( $column_name ) {
            case 'focus_keyword':
                return esc_html( get_post_meta( $item->ID, 'travel_generator_focus_keyword', true ) );
            case 'date':
                return esc_html( get_the_date( '', $item ) );
            default:
                return print_r( $item, true ); // For debugging, should not happen
        }
    }

    function column_title( $item ) {
        $post_id = $item->ID;
        $title = get_the_title( $post_id );
        $post_status_obj = get_post_status_object( $item->post_status );
        $status_label = $post_status_obj ? ' — <span class="post-state">' . esc_html($post_status_obj->label) . '</span>' : '';

        $actions = [];
        $can_edit_post = current_user_can( 'edit_post', $post_id );

        // Edit Link
        if ( $can_edit_post && 'trash' !== $item->post_status ) {
            $actions['edit'] = sprintf(
                '<a href="%s" aria-label="%s">%s</a>',
                get_edit_post_link( $post_id ),
                esc_attr( sprintf( __( 'Edit &#8220;%s&#8221;', 'travel-genie-wp' ), $title ) ),
                __( 'Edit', 'travel-genie-wp' )
            );
        }

        // Quick Edit Link
        if ( $can_edit_post && 'trash' !== $item->post_status ) {
            $actions['inline hide-if-no-js'] = sprintf( // Key used by WP core for Quick Edit
                '<a href="#" class="editinline" aria-label="%s">%s</a>',
                esc_attr( sprintf( __( 'Quick edit &#8220;%s&#8221; inline', 'travel-genie-wp' ), $title ) ),
                __( 'Quick Edit', 'travel-genie-wp' )
            );
        }
        
        // Trash/Restore/Delete Permanently Links
        if ( current_user_can( 'delete_post', $post_id ) ) {
            if ( 'trash' === $item->post_status ) {
                $actions['untrash'] = sprintf(
                    '<a href="%s" aria-label="%s">%s</a>',
                    wp_nonce_url( admin_url( sprintf( 'post.php?action=untrash&post=%d', $post_id ) ), 'untrash-post_' . $post_id ),
                    esc_attr( sprintf( __( 'Restore &#8220;%s&#8221; from the Trash', 'travel-genie-wp' ), $title ) ),
                    __( 'Restore', 'travel-genie-wp' )
                );
                $actions['delete'] = sprintf(
                    '<a href="%s" class="submitdelete" aria-label="%s">%s</a>',
                    wp_nonce_url( admin_url( sprintf( 'post.php?action=delete&post=%d', $post_id ) ), 'delete-post_' . $post_id ),
                    esc_attr( sprintf( __( 'Delete &#8220;%s&#8221; permanently', 'travel-genie-wp' ), $title ) ),
                    __( 'Delete Permanently', 'travel-genie-wp' )
                );
            } else { // Not in trash
                $actions['trash'] = sprintf(
                    '<a href="%s" class="submitdelete" aria-label="%s">%s</a>',
                    wp_nonce_url( admin_url( sprintf( 'post.php?action=trash&post=%d', $post_id ) ), 'trash-post_' . $post_id ),
                    esc_attr( sprintf( __( 'Move &#8220;%s&#8221; to the Trash', 'travel-genie-wp' ), $title ) ),
                    __( 'Trash', 'travel-genie-wp' )
                );
            }
        }
        
        // Preview Link (using 'view' key for better WP integration)
        if ( 'trash' !== $item->post_status && $can_edit_post ) { // Also check $can_edit_post for preview capability
            $preview_link = get_preview_post_link( $post_id );
            if ( $preview_link ) {
                $actions['view'] = sprintf(
                    '<a href="%s" rel="noopener noreferrer bookmark" aria-label="%s" target="_blank">%s</a>',
                    esc_url( $preview_link ),
                    esc_attr( sprintf( __( 'Preview &#8220;%s&#8221;', 'travel-genie-wp' ), $title ) ),
                    __( 'Preview', 'travel-genie-wp' )
                );
            }
        }

        $row_actions_output = $this->row_actions( $actions );

        // Main title link
        $main_title_link_href = $can_edit_post ? esc_url( get_edit_post_link( $post_id ) ) : '#'; // Link to edit if possible
        // ARIA label for the main title link
        $main_title_link_aria_label = $can_edit_post ? esc_attr( sprintf( __( 'Edit &#8220;%s&#8221;', 'travel-genie-wp' ), $title ) ) : esc_attr( $title );

        return sprintf( '<strong><a class="row-title" href="%s" aria-label="%s">%s</a>%s</strong>%s',
            $main_title_link_href,
            $main_title_link_aria_label,
            esc_html( $title ), // Title text
            $status_label,
            $row_actions_output
        );
    }

    protected function column_cb( $item ) {
        return sprintf(
            '<input type="checkbox" name="post[]" value="%s" />',
            $item->ID
        );
    }
}

/**
 * Render the "Generated Articles" admin page.
 */
function travel_generator_page_generated_articles_html() {
    if ( ! current_user_can( 'manage_options' ) ) { 
        wp_die( __( 'You do not have sufficient permissions to access this page.', 'travel-genie-wp' ) );
    }

    // Check for success message from redirect
    if ( isset( $_GET['post_created'] ) && isset( $_GET['message'] ) ) {
        $post_id = intval( $_GET['post_created'] );
        $message = sanitize_text_field( urldecode( $_GET['message'] ) );
        if ( $post_id > 0 && ! empty( $message ) ) {
            $edit_link = get_edit_post_link( $post_id );
            $display_message = $message;
            if ( $edit_link ) {
                $display_message .= ' <a href="' . esc_url( $edit_link ) . '">' . __( 'Edit Post', 'travel-genie-wp' ) . '</a>';
            }
            echo '<div id="message" class="notice notice-success is-dismissible"><p>' . wp_kses_post( $display_message ) . '</p></div>';
        }
    }

    $list_table = new Travel_Generator_Generated_Articles_List_Table();
    $list_table->prepare_items();
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <p><?php _e( 'Below is a list of travel articles generated by the AI. You can view, edit, or delete them from here.', 'travel-genie-wp' ); ?></p>
        
        <form method="post">
            <?php
            $list_table->search_box( __( 'Search Articles', 'travel-genie-wp' ), 'article' );
            $list_table->display(); 
            ?>
        </form>
    </div>
    <?php
}

/**
 * Render the "Generate Article" admin page.
 */
function travel_generator_page_generate_article_html() {
    // Ensure the user has the 'manage_options' capability to access this page.
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( __( 'You do not have sufficient permissions to access this page.', 'travel-genie-wp' ) );
    }

    // Initialize variables to prevent undefined notices
    $admin_notice_message = '';
    $admin_notice_type = '';

    // Handle form submission for generating article content
    if ( isset( $_POST['action'] ) && $_POST['action'] === 'generate_article_content' ) {
        check_admin_referer( 'generate_article_action', 'travel_generator_nonce' );

        // Prepare args for the API call
        $args = [
            'post_title'      => isset( $_POST['post_title'] ) ? sanitize_text_field( $_POST['post_title'] ) : '',
            'focus_keyword'   => isset( $_POST['focus_keyword'] ) ? sanitize_text_field( $_POST['focus_keyword'] ) : '',
            'related_keywords' => isset( $_POST['related_keywords'] ) ? sanitize_text_field( $_POST['related_keywords'] ) : '',
            'internal_link'   => isset( $_POST['internal_link'] ) ? esc_url_raw( $_POST['internal_link'] ) : '',
            'external_link'   => isset( $_POST['external_link'] ) ? esc_url_raw( $_POST['external_link'] ) : '',
            'generate_featured_image' => isset( $_POST['generate_featured_image'] ), // Will be true if checked, not present if unchecked
            'generate_destination_image' => isset( $_POST['generate_destination_image'] ),
            'generate_activities_image' => isset( $_POST['generate_activities_image'] ),
        ];
        
        $result = travel_generator_generate_article_post( $args );
        
        if ( $result['success'] && $result['post_id'] ) {
            // Article created successfully, set message for current page
            $admin_notice_message = '<span class="dashicons dashicons-yes-alt"></span> ' . __( 'Travel article created successfully', 'travel-genie-wp' ) . ' <a href="' . esc_url( get_edit_post_link( $result['post_id'] ) ) . '">' . __( 'Edit Post', 'travel-genie-wp' ) . '</a>';
            $admin_notice_type = 'success';
        } else {
            // Store error message to display as an admin notice
            $admin_notice_message = $result['message'];
            $admin_notice_type = 'error';
        }
    }

    ?>
    <div class="wrap">
        <div style="display: flex; align-items: center;"><img src="<?php echo esc_url( plugins_url( 'assets/icon-256x256.png', __FILE__ ) ); ?>" alt="Travel Genie WP Icon" style="width: 100px; height: 100px; margin-right: 8px;"><h1><?php echo esc_html( get_admin_page_title() ); ?></h1></div>
        <div id="travel-generator-message" style="margin-bottom: 15px; display: none;"></div>

        <div id="travel-generation-status" style="margin-bottom: 15px;"></div>

        <?php if ( ! empty( $admin_notice_message ) ) : ?>
            <div id="message" class="notice <?php echo $admin_notice_type === 'error' ? 'notice-error' : 'notice-success'; ?> is-dismissible">
                <p><?php echo wp_kses_post( $admin_notice_message ); ?></p>
            </div>
        <?php endif; ?>

        <p><?php _e( 'Generate Travel Article: Use the form below to generate a new travel article. The AI will craft a comprehensive blog post based on your input, and it will be automatically saved as a draft in your \'Generated Articles\' list.', 'travel-genie-wp' ); ?></p>
        
        <form method="post" action="" id="travel-generator-form">
            <?php wp_nonce_field( 'generate_article_action', 'travel_generator_nonce' ); ?>
            <input type="hidden" name="action" value="generate_article_content">

            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><label for="post_title"><?php _e( 'Blog Post Title', 'travel-genie-wp' ); ?></label></th>
                    <td>
                        <input type="text" id="post_title" name="post_title" value="<?php echo esc_attr( $_POST['post_title'] ?? '' ); ?>" class="regular-text" required />
                        <p class="description"><?php _e( 'The main title for your travel blog post (e.g., "Hidden Gems in Paris: A Local\'s Guide"). This will be the H1 of your post.', 'travel-genie-wp' ); ?></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="focus_keyword"><?php _e( 'Focus Keyword', 'travel-genie-wp' ); ?></label></th>
                    <td>
                        <input type="text" id="focus_keyword" name="focus_keyword" value="<?php echo esc_attr( $_POST['focus_keyword'] ?? '' ); ?>" class="regular-text" required />
                        <p class="description"><?php _e( 'The primary keyword you want this post to rank for (e.g., "hidden gems Paris" or "Paris travel guide").', 'travel-genie-wp' ); ?></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="related_keywords"><?php _e( 'Related Keywords', 'travel-genie-wp' ); ?></label></th>
                    <td>
                        <input type="text" id="related_keywords" name="related_keywords" value="<?php echo esc_attr( $_POST['related_keywords'] ?? '' ); ?>" class="regular-text" />
                        <p class="description"><?php _e( 'Enter related keywords, separated by commas (e.g., "Paris attractions, local experiences, travel tips"). These will be used to enrich the content.', 'travel-genie-wp' ); ?></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="internal_link"><?php _e( 'Internal Link URL (Optional)', 'travel-genie-wp' ); ?></label></th>
                    <td>
                        <input type="url" id="internal_link" name="internal_link" value="<?php echo esc_url( $_POST['internal_link'] ?? '' ); ?>" class="regular-text" placeholder="https://yourwebsite.com/related-post" />
                        <p class="description"><?php _e( 'If you want the Focus Keyword to be linked, provide the URL here. Leave empty for no link.', 'travel-genie-wp' ); ?></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="external_link"><?php _e( 'External Link URL (Optional)', 'travel-genie-wp' ); ?></label></th>
                    <td>
                        <input type="url" id="external_link" name="external_link" value="<?php echo esc_url( $_POST['external_link'] ?? '' ); ?>" class="regular-text" placeholder="https://externalsite.com/resource" />
                        <p class="description"><?php _e( 'If you want Related Keywords to be linked, provide a primary URL here. Leave empty for no link.', 'travel-genie-wp' ); ?></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php _e( 'Image Generation Options', 'travel-genie-wp' ); ?></th>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text"><span><?php _e( 'Image Generation Options', 'travel-genie-wp' ); ?></span></legend>
                            <label for="generate_featured_image">
                                <input name="generate_featured_image" type="checkbox" id="generate_featured_image" value="1" <?php checked( !isset($_POST['action']) || isset($_POST['generate_featured_image']) ); ?>>
                                <?php _e( 'Generate Featured Image', 'travel-genie-wp' ); ?>
                            </label>
                            <br>
                            <label for="generate_destination_image">
                                <input name="generate_destination_image" type="checkbox" id="generate_destination_image" value="1" <?php checked( !isset($_POST['action']) || isset($_POST['generate_destination_image']) ); ?>>
                                <?php _e( 'Generate Destination Image (in content)', 'travel-genie-wp' ); ?>
                            </label>
                            <br>
                            <label for="generate_activities_image">
                                <input name="generate_activities_image" type="checkbox" id="generate_activities_image" value="1" <?php checked( !isset($_POST['action']) || isset($_POST['generate_activities_image']) ); ?>>
                                <?php _e( 'Generate Activities Image (in content)', 'travel-genie-wp' ); ?>
                            </label>
                            <p class="description"><?php _e( 'Select which images should be automatically generated by Fal AI. Requires Fal AI API Key to be set.', 'travel-genie-wp' ); ?></p>
                        </fieldset>
                    </td>
                </tr>
            </table>
            <?php submit_button( __( 'Generate Travel Article & Save as Draft', 'travel-genie-wp' ), 'primary', 'submit_generate_content' ); ?>
        </form>

    </div>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {
            const form = document.getElementById('travel-generator-form');
            const messageDiv = document.getElementById('travel-generator-message');
            const generateButton = document.getElementById('submit_generate_content');

            if (form && messageDiv && generateButton) {
                form.addEventListener('submit', function (event) {
                    event.preventDefault();

                    messageDiv.innerHTML = '<p><span class="spinner is-active" style="float: left; margin-right: 5px;"></span> <?php echo esc_js(__('Generating travel article, please wait... This may take a moment.', 'travel-genie-wp')); ?></p>';
                    messageDiv.className = 'notice notice-info is-dismissible';
                    messageDiv.style.display = 'block';
                    generateButton.disabled = true;

                    const formData = new FormData(form);
                    formData.set('action', 'generate_article_content_ajax'); // Ensure correct AJAX action for the handler

                    fetch(ajaxurl, { // ajaxurl is a global JS variable in WordPress admin
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        generateButton.disabled = false;
                        if (data.success) {
                            messageDiv.className = 'notice notice-success is-dismissible';
                            messageDiv.innerHTML = `<p>${data.data.message}</p>`; // Access message from data.data
                            form.reset(); // Reset form fields on success
                        } else {
                            messageDiv.className = 'notice notice-error is-dismissible';
                            messageDiv.innerHTML = `<p>${data.data.message || '<?php echo esc_js(__('An unknown error occurred.', 'travel-genie-wp')); ?>'}</p>`;
                        }
                        messageDiv.style.display = 'block';
                    })
                    .catch(error => {
                        generateButton.disabled = false;
                        messageDiv.className = 'notice notice-error is-dismissible';
                        console.error('Error:', error);
                        messageDiv.innerHTML = `<p><?php echo esc_js(__('Request failed. Please check the console for details or try again.', 'travel-genie-wp')); ?></p>`;
                        messageDiv.style.display = 'block';
                    });
                });
            }
        });
    </script>
    <?php
}



/**
 * Callback for the settings page.
 */
function travel_generator_settings_page_html() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <form action="options.php" method="post">
            <?php
            settings_fields( 'travel_generator_options' );
            do_settings_sections( 'travel-generator-settings' );
            submit_button( __( 'Save Settings', 'travel-genie-wp' ) );
            ?>
        </form>
    </div>
    <?php
}

/**
 * Register settings.
 */
function travel_generator_register_settings() {
    register_setting( 'travel_generator_options', 'travel_generator_settings', 'travel_generator_sanitize_settings' );

    // OpenRouter API Settings Section
    add_settings_section(
        'travel_generator_section_api', // ID
        __( 'OpenRouter API Settings', 'travel-genie-wp' ), // Title
        'travel_generator_section_api_callback', // Callback
        'travel-generator-settings' // Page slug where this section will be shown
    );

    add_settings_field(
        'api_key', // ID
        __( 'OpenRouter API Key', 'travel-genie-wp' ), // Title
        'travel_generator_field_api_key_html', // Callback to render HTML
        'travel-generator-settings', // Page slug
        'travel_generator_section_api', // Section ID
        [ 'label_for' => 'travel_generator_settings[api_key]' ] // Args
    );

    add_settings_field(
        'selected_model', // ID
        __( 'Select LLM Model', 'travel-genie-wp' ), // Title
        'travel_generator_field_model_html', // Callback to render HTML
        'travel-generator-settings', // Page slug
        'travel_generator_section_api', // Section ID
        [ 'label_for' => 'travel_generator_settings[selected_model]' ] // Args
    );

    // Fal AI Settings Section
    add_settings_section(
        'travel_generator_section_fal_ai', // ID
        __( 'Fal AI Settings (for Image Generation)', 'travel-genie-wp' ), // Title
        'travel_generator_section_fal_ai_callback', // Callback
        'travel-generator-settings' // Page slug
    );

    add_settings_field(
        'fal_ai_api_key', // ID
        __( 'Fal AI API Key', 'travel-genie-wp' ), // Title
        'travel_generator_field_fal_ai_api_key_html', // Callback to render HTML
        'travel-generator-settings', // Page slug
        'travel_generator_section_fal_ai', // Section ID
        [ 'label_for' => 'travel_generator_settings[fal_ai_api_key]' ] // Args
    );
}
add_action( 'admin_init', 'travel_generator_register_settings' );

/**
 * Callback for the Fal AI settings section.
 */
function travel_generator_section_fal_ai_callback() {
    echo '<p>' . esc_html__( 'Enter your Fal AI API key for image generation.', 'travel-genie-wp' ) . '</p>';
}

/**
 * Render HTML for the Fal AI API Key field.
 */
function travel_generator_field_fal_ai_api_key_html( $args ) {
    $options = get_option( 'travel_generator_settings' );
    ?>
    <input type="password" id="<?php echo esc_attr( $args['label_for'] ); ?>" name="travel_generator_settings[fal_ai_api_key]" value="<?php echo esc_attr( $options['fal_ai_api_key'] ?? '' ); ?>" class="regular-text">
    <p class="description"><?php esc_html_e( 'Your Fal AI API key (e.g., Key YOUR_FAL_KEY_ID:YOUR_FAL_KEY_SECRET). The plugin will prepend "Key " if not present.', 'travel-genie-wp' ); ?></p>
    <?php
}

/**
 * Callback for the API settings section.
 */
function travel_generator_section_api_callback() {
    echo '<p>' . esc_html__( 'Enter your OpenRouter API key and choose your preferred model.', 'travel-genie-wp' ) . '</p>';
}

/**
 * Render HTML for the API Key field.
 */
function travel_generator_field_api_key_html( $args ) {
    $options = get_option( 'travel_generator_settings' );
    ?>
    <input type="password" id="<?php echo esc_attr( $args['label_for'] ); ?>" name="travel_generator_settings[api_key]" value="<?php echo esc_attr( $options['api_key'] ?? '' ); ?>" class="regular-text">
    <p class="description"><?php esc_html_e( 'Your OpenRouter API key.', 'travel-genie-wp' ); ?></p>
    <?php
}

/**
 * Render HTML for the LLM Model selection field.
 */
function travel_generator_field_model_html( $args ) {
    $options = get_option( 'travel_generator_settings' );
    $current_selected_model = $options['selected_model'] ?? 'openai/gpt-3.5-turbo'; // Default model

    $available_models = travel_generator_get_available_models();

    ?>
    <select id="<?php echo esc_attr( $args['label_for'] ); ?>" name="travel_generator_settings[selected_model]">
        <?php foreach ( $available_models as $model_id => $model_name ) : ?>
            <option value="<?php echo esc_attr( $model_id ); ?>" <?php selected( $current_selected_model, $model_id ); ?>>
                <?php echo esc_html( $model_name ); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <button type="button" id="refresh-models-button" class="button"> <?php _e('Refresh List', 'travel-genie-wp'); ?> </button>
    <span id="refresh-models-status" style="margin-left: 10px;"></span>
    <p class="description"><?php esc_html_e( 'Choose the language model for generating travel articles. Click "Refresh List" to fetch the latest models from OpenRouter (requires API key to be set).', 'travel-genie-wp' ); ?></p>
    
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#refresh-models-button').on('click', function() {
                var $button = $(this);
                var $status = $('#refresh-models-status');
                var $select = $('#<?php echo esc_js( $args['label_for'] ); ?>'); // Use the ID passed to the function
                var originalSelectedValue = $select.val();

                $button.prop('disabled', true);
                $status.html('<span class="spinner is-active" style="float:none; vertical-align: middle;"></span> ' + '<?php echo esc_js(__('Refreshing models...', 'travel-genie-wp')); ?>')
                       .attr('class', 'notice notice-info inline travel-generator-notice')
                       .css('display', 'inline-block');

                $.ajax({
                    url: '<?php echo esc_js(admin_url( 'admin-ajax.php' )); ?>',
                    type: 'POST',
                    data: {
                        action: 'travel_generator_refresh_models',
                        security: '<?php echo esc_js(wp_create_nonce( 'travel_generator_refresh_models_nonce' )); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            $status.html('<?php echo esc_js(__('Model list refreshed!', 'travel-genie-wp')); ?>')
                                   .attr('class', 'notice notice-success inline travel-generator-notice');
                            $select.empty();
                            if (response.data.models && Object.keys(response.data.models).length > 0) {
                                var modelExists = false;
                                $.each(response.data.models, function(id, name) {
                                    var $option = $('<option>', { value: id, text: name });
                                    if (id === originalSelectedValue) {
                                        $option.prop('selected', true);
                                        modelExists = true;
                                    }
                                    $select.append($option);
                                });
                                if (!modelExists && $select.find('option').length > 0) {
                                    $select.find('option:first').prop('selected', true);
                                }
                            } else {
                                $status.html('<?php echo esc_js(__('No models returned from API.', 'travel-genie-wp')); ?>')
                                       .attr('class', 'notice notice-warning inline travel-generator-notice');
                            }
                        } else {
                            var errorMessage = '<?php echo esc_js(__('Error. Check console.', 'travel-genie-wp')); ?>';
                            if (response.data && response.data.message) {
                                errorMessage += ' ' + response.data.message; // Append specific error from server
                            }
                            $status.html(errorMessage).attr('class', 'notice notice-error inline travel-generator-notice');
                            console.error('Error refreshing models:', response.data ? response.data.message : 'Unknown error');
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        $status.html('<?php echo esc_js(__('AJAX error. Check console.', 'travel-genie-wp')); ?>').attr('class', 'notice notice-error inline travel-generator-notice');
                        console.error('AJAX error:', textStatus, errorThrown);
                    },
                    complete: function() {
                        $button.prop('disabled', false);
                        setTimeout(function() {
                            $status.fadeOut(function() { $(this).html('').removeAttr('class').removeAttr('style'); });
                        }, 7000);
                    }
                });
            });

            // Basic styling for notices, if not already present
            if ($('style#travel-generator-admin-styles').length === 0) {
                $('<style id="travel-generator-admin-styles">' +
                  '.travel-generator-notice.inline { margin-left: 10px; padding: 5px 10px; }' +
                  '.travel-generator-notice .spinner { margin-right: 5px; }' +
                  '</style>').appendTo('head');
            }
        });
    </script>
    <?php
}

/**
 * Sanitize settings.
 */
function travel_generator_sanitize_settings( $input ) {
    $new_input = [];

    if ( isset( $input['api_key'] ) ) {
        $new_input['api_key'] = sanitize_text_field( $input['api_key'] );
    }

    if ( isset( $input['selected_model'] ) ) {
        $new_input['selected_model'] = sanitize_text_field( $input['selected_model'] );
    }

    if ( isset( $input['fal_ai_api_key'] ) ) {
        $fal_key = sanitize_text_field( $input['fal_ai_api_key'] );
        // Ensure the key starts with "Key " for Fal AI authorization header
        if ( !empty($fal_key) && strpos($fal_key, 'Key ') !== 0 ) {
            // Check if it's in the format key_id:key_secret without "Key " prefix
            if (preg_match('/^[a-zA-Z0-9]+:[a-zA-Z0-9]+$/', $fal_key)) {
                 $new_input['fal_ai_api_key'] = 'Key ' . $fal_key;
            } else {
                // If it's some other format or just a partial key, store as is for now
                $new_input['fal_ai_api_key'] = $fal_key; 
            }
        } else {
            $new_input['fal_ai_api_key'] = $fal_key;
        }
    }

    return $new_input;
}

/**
 * Function to get the cached models or a default list
 */
function travel_generator_get_available_models() {
    $cached_models = get_option('travel_generator_models_cache');
    if ( !empty($cached_models) && is_array($cached_models) ) {
        return $cached_models;
    }
    // Fallback to a default list if cache is empty or invalid
    return [
        'openai/gpt-3.5-turbo' => 'OpenAI: GPT-3.5 Turbo (Default)',
        'openai/gpt-4' => 'OpenAI: GPT-4',
        'openai/gpt-4o' => 'OpenAI: GPT-4o',
        'anthropic/claude-3-opus-20240229' => 'Anthropic: Claude 3 Opus',
        'anthropic/claude-3-sonnet-20240229' => 'Anthropic: Claude 3 Sonnet',
        'anthropic/claude-3-haiku-20240307' => 'Anthropic: Claude 3 Haiku',
        'google/gemini-pro' => 'Google: Gemini Pro',
        'meta-llama/llama-3-70b-instruct' => 'Meta: Llama 3 70B Instruct',
        'mistralai/mistral-7b-instruct' => 'Mistral AI: Mistral 7B Instruct',
    ];
}

/**
 * Function to fetch models from OpenRouter API
 */
function travel_generator_fetch_and_cache_models() {
    $options = get_option('travel_generator_settings');
    $api_key = $options['api_key'] ?? '';

    if (empty($api_key)) {
        return new WP_Error('api_key_missing', __('API key is not set. Please set your OpenRouter API Key in the plugin settings.', 'travel-genie-wp'));
    }

    $api_url = 'https://openrouter.ai/api/v1/models';
    $request_args = [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
            'HTTP-Referer'  => get_site_url(), // Required by OpenRouter
            'X-Title'       => get_bloginfo('name') // Optional: Your site name
        ],
        'timeout' => 30,
    ];

    $response = wp_remote_get($api_url, $request_args);

    if (is_wp_error($response)) {
        return new WP_Error('api_request_failed', $response->get_error_message());
    }

    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = wp_remote_retrieve_body($response);

    if ($response_code !== 200) {
        $error_data = json_decode($response_body, true);
        $error_message = $error_data['error']['message'] ?? __('Unknown API error while fetching models.', 'travel-genie-wp');
        return new WP_Error('api_error', sprintf(__('API Error (%d): %s', 'travel-genie-wp'), $response_code, $error_message));
    }

    $data = json_decode($response_body, true);

    if (!isset($data['data']) || !is_array($data['data'])) {
        return new WP_Error('invalid_response_format', __('Unexpected API response format when fetching models.', 'travel-genie-wp'));
    }

    $models = [];
    foreach ($data['data'] as $model_data) {
        if (isset($model_data['id']) && isset($model_data['name'])) {
            $models[$model_data['id']] = $model_data['name'] . (isset($model_data['id']) && $model_data['id'] === 'openai/gpt-3.5-turbo' ? ' (Default)' : '');
        }
    }

    if (empty($models)) {
        return new WP_Error('no_models_found', __('No models found in API response.', 'travel-genie-wp'));
    }

    update_option('travel_generator_models_cache', $models);
    return $models;
}

/**
 * AJAX handler for refreshing models
 */
add_action('wp_ajax_travel_generator_refresh_models', 'travel_generator_ajax_refresh_models');

function travel_generator_ajax_refresh_models() {
    // Verify nonce for security
    check_ajax_referer('travel_generator_refresh_models_nonce', 'security');

    $result = travel_generator_fetch_and_cache_models();

    if (is_wp_error($result)) {
        wp_send_json_error(['message' => $result->get_error_message()]);
    } else {
        wp_send_json_success(['models' => $result]);
    }
}

/**
 * AJAX handler for generating article content.
 */
add_action( 'wp_ajax_generate_article_content_ajax', 'travel_generator_ajax_generate_content_handler' );

function travel_generator_ajax_generate_content_handler() {
    // Verify the nonce
    check_ajax_referer( 'generate_article_action', 'travel_generator_nonce' );

    // Prepare args for the API call directly from $_POST values
    $args = [
        'post_title'      => isset( $_POST['post_title'] ) ? sanitize_text_field( $_POST['post_title'] ) : '',
        'focus_keyword'   => isset( $_POST['focus_keyword'] ) ? sanitize_text_field( $_POST['focus_keyword'] ) : '',
        'related_keywords' => isset( $_POST['related_keywords'] ) ? sanitize_text_field( $_POST['related_keywords'] ) : '',
        'internal_link'   => isset( $_POST['internal_link'] ) ? esc_url_raw( $_POST['internal_link'] ) : '',
        'external_link'   => isset( $_POST['external_link'] ) ? esc_url_raw( $_POST['external_link'] ) : '',
        'generate_featured_image' => isset( $_POST['generate_featured_image'] ), // Checkbox value
        'generate_destination_image' => isset( $_POST['generate_destination_image'] ), // Checkbox value
        'generate_activities_image' => isset( $_POST['generate_activities_image'] ), // Checkbox value
    ];

    // Call the existing function to generate the post
    $result = travel_generator_generate_article_post( $args );

    if ( $result['success'] && $result['post_id'] ) {
        $edit_link_html = ' <a href="' . esc_url( get_edit_post_link( $result['post_id'], 'raw' ) ) . '">' . esc_html__( 'Edit Post', 'travel-genie-wp' ) . '</a>';
        $final_ajax_message = $result['message'] . $edit_link_html;

        wp_send_json_success( [
            'message'   => $final_ajax_message,
            'post_id'   => $result['post_id']
        ] );
    } else {
        wp_send_json_error( [
            'message' => $result['message'] ? $result['message'] : __( 'An unknown error occurred during article generation.', 'travel-genie-wp' ),
        ] );
    }
}


/**
 * Generate an image using Fal AI, upload it to WordPress Media Library, and return the attachment ID.
 *
 * @param string $prompt The image prompt.
 * @param string $post_title The title of the post, used for image alt text.
 * @param string $focus_keyword_for_alt The focus keyword for alt text.
 * @return int|false The attachment ID on success, false on failure.
 */
function travel_generator_generate_and_upload_fal_image( $prompt, $post_title, $focus_keyword_for_alt ) {
    $options = get_option( 'travel_generator_settings' );
    $fal_api_key = isset( $options['fal_ai_api_key'] ) ? $options['fal_ai_api_key'] : '';

    if ( empty( $fal_api_key ) ) {
        error_log( 'Fal AI API Key is not set. Skipping image generation.' );
        return false;
    }

    if ( empty( $prompt ) ) {
        error_log('Prompt is empty, cannot generate Fal AI image.');
        return false;
    }

    // Ensure the API key starts with "Key " if it's in the id:secret format
    if (strpos($fal_api_key, 'Key ') !== 0 && preg_match('/^[a-zA-Z0-9\-_]+:[a-zA-Z0-9\-_]+$/', $fal_api_key)) {
        $fal_api_key = 'Key ' . $fal_api_key;
    }

    $initial_request_url = 'https://fal.run/fal-ai/recraft/v3/text-to-image';
    $initial_request_args = [
        'method'  => 'POST',
        'headers' => [
            'Authorization' => $fal_api_key,
            'Content-Type'  => 'application/json',
        ],
        'body'    => json_encode( [
            'prompt'     => $prompt,
            'image_size' => 'landscape_4_3',
            'style'      => 'realistic_image',
            'colors'     => []
        ] ),
        'timeout' => 30,
    ];

    $initial_response = wp_remote_post( $initial_request_url, $initial_request_args );

    if ( is_wp_error( $initial_response ) ) {
        error_log( 'Fal AI initial request failed: ' . $initial_response->get_error_message() );
        return false;
    }

    $initial_body = wp_remote_retrieve_body( $initial_response );
    $initial_data = json_decode( $initial_body, true );
    $image_url = null;

    // Check if the initial response contains the image URL directly
    if ( isset( $initial_data['images'][0]['url'] ) ) {
        $image_url = $initial_data['images'][0]['url'];
        error_log( "Fal AI: Image URL found directly in initial response: " . $image_url );
    } elseif ( isset( $initial_data['request_id'] ) ) {
        // Proceed with polling if request_id is present and no direct image URL
        $request_id = $initial_data['request_id'];
        error_log( "Fal AI: Initial response contains request_id: {$request_id}. Proceeding with polling." );
        $status_url_base = 'https://fal.run/fal-ai/recraft/v3/text-to-image/requests/';
        $status_url = $status_url_base . $request_id . '/response';
        
        $max_retries = 10;
        $retry_delay = 15;

        for ( $i = 0; $i < $max_retries; $i++ ) {
            sleep( $retry_delay );
            $status_response = wp_remote_get( $status_url, array(
                'headers' => array('Authorization' => $fal_api_key),
                'timeout' => 20,
            ) );

            if ( is_wp_error( $status_response ) ) {
                error_log( "Fal AI status check failed for request_id {$request_id}: " . $status_response->get_error_message() );
                continue;
            }

            $status_code = wp_remote_retrieve_response_code( $status_response );
            $status_body = wp_remote_retrieve_body( $status_response );
            $status_data = json_decode( $status_body, true );

            // Check for explicit status field first
            if ( isset( $status_data['status'] ) ) {
                $current_status = strtolower( $status_data['status'] );
                if ( $current_status === 'completed' || $current_status === 'succeeded' ) {
                    if ( isset( $status_data['image_url'] ) ) {
                        $image_url = $status_data['image_url'];
                        error_log("Fal AI image for request_id {$request_id} completed. Image URL found.");
                        break;
                    } elseif (isset($status_data['response']['image_url'])) {
                        $image_url = $status_data['response']['image_url'];
                        error_log("Fal AI image for request_id {$request_id} completed. Nested image URL found.");
                        break;
                    } else {
                        error_log("Fal AI image for request_id {$request_id} status is {$current_status}, but no image_url found. Body: " . $status_body);
                    }
                } elseif ( $current_status === 'failed' || $current_status === 'error' ) {
                    error_log("Fal AI image for request_id {$request_id} failed with status: {$current_status}. Body: " . $status_body);
                    return false;
                } elseif ( $current_status === 'processing' || $current_status === 'in_progress' || $current_status === 'pending' ) {
                    error_log("Fal AI image for request_id {$request_id} status: {$current_status} (Attempt: " . ($i+1) . ")");
                } else {
                    error_log("Fal AI image for request_id {$request_id} has unknown status: {$current_status}. Body: " . $status_body);
                }
            } elseif ( $status_code === 200 && isset($status_data['image_url']) ) {
                $image_url = $status_data['image_url'];
                error_log("Fal AI image for request_id {$request_id} image_url found directly (no explicit status field).");
                break;
            } else {
                error_log("Fal AI status check for request_id {$request_id} returned status code {$status_code} with no explicit status or image_url. Body: " . $status_body);
            }
        }
    }

    if ( empty( $image_url ) ) {
        error_log( "Fal AI image generation timed out or no image_url found." );
        return false;
    }

    error_log("Fal AI: Successfully retrieved image URL: {$image_url}. Attempting to sideload.");

    // We need 'wp-admin/includes/media.php', 'wp-admin/includes/file.php', 'wp-admin/includes/image.php'
    if ( !function_exists('media_sideload_image') ) {
        require_once( ABSPATH . 'wp-admin/includes/media.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
    }

    // Sideload the image
    $image_description = sanitize_text_field( $focus_keyword_for_alt );
    
    error_log("Fal AI: Calling media_sideload_image with URL: {$image_url} and description: {$image_description}");
    $attachment_id = media_sideload_image( $image_url, 0, esc_html( $image_description ), 'id' );

    if ( is_wp_error( $attachment_id ) ) {
        error_log( 'Fal AI image sideload failed. URL was: ' . $image_url . ' | WordPress Error: ' . $attachment_id->get_error_message() );
        return false;
    } else if ( !$attachment_id || !is_numeric($attachment_id) ){
        error_log( 'Fal AI image sideload did not return a valid attachment ID. URL was: ' . $image_url . ' | Result: ' . print_r($attachment_id, true) );
        return false;
    }

    error_log("Fal AI: Successfully sideloaded image. Attachment ID: {$attachment_id} from URL: {$image_url}");
    return $attachment_id;
}

/**
 * Generate travel article post content using OpenRouter API.
 *
 * @param array $args Article generation arguments.
 * @return array Result array with success status, post ID, and message.
 */
function travel_generator_generate_article_post( $args ) {
    $options = get_option( 'travel_generator_settings' );
    $api_key = isset( $options['api_key'] ) ? $options['api_key'] : '';
    $selected_model = isset( $options['selected_model'] ) && !empty( $options['selected_model'] ) ? $options['selected_model'] : 'openai/gpt-3.5-turbo';

    if ( empty( $api_key ) ) {
        return [
            'success' => false,
            'post_id' => null,
            'message' => __( 'Error: API Key is not configured. Please set your OpenRouter API Key in the plugin settings.', 'travel-genie-wp' ),
            'content' => null
        ];
    }

    // Use provided args or fall back to empty strings if not set
    $post_title      = !empty($args['post_title']) ? $args['post_title'] : __( 'New Travel Article', 'travel-genie-wp' );
    $focus_keyword   = !empty($args['focus_keyword']) ? $args['focus_keyword'] : '';
    $related_keywords = !empty($args['related_keywords']) ? $args['related_keywords'] : '';
    $internal_link   = !empty($args['internal_link']) ? $args['internal_link'] : '#';
    $external_link   = !empty($args['external_link']) ? $args['external_link'] : '';

    // Image generation flags
    $generate_featured_image = !empty($args['generate_featured_image']);
    $generate_destination_image = !empty($args['generate_destination_image']);
    $generate_activities_image = !empty($args['generate_activities_image']);

    // Construct the travel-specific prompt for HTML output
    $base_prompt = "Act as a professional travel blogger, SEO specialist, and tourism content expert. Create a comprehensive, engaging, and SEO-optimized travel blog post that is 1,000+ words long formatted directly in HTML suitable for a WordPress post. Follow the structure and guidelines below to produce content that is informative, authentic, and optimized for both readers and search engines.

Blog Post Title: %s 
Focus Keyword: %s

Important: Ensure all paragraphs in the generated content are concise, ideally under 60 words each, to maintain readability.
Related keywords: %s

Integrate the focus keyword naturally throughout the post, particularly in the main title (e.g., <h1>Title</h1> or as the post title itself), subheadings (e.g., <h2>Section</h2> or <h3>Subsection</h3>), and within the first 100 words (e.g., in a <p> tag).
Use semantic variations and related keywords to enhance search engine context and relevance.

HTML Formatting for Specific Keywords:
1. Focus Keyword Linking: The Focus Keyword for this article is '%s'. The Internal Link URL is '%s'. In the HTML content you generate, please find up to 4 natural textual occurrences of this Focus Keyword. For each of these occurrences (up to a maximum of 4), format it exactly as: <a href=\"%s\" target=\"_blank\"><strong>%s</strong></a>.
2. Related Keyword Linking: The list of Related Keywords for this article is: '%s'. The External Link URL is '%s'. In the HTML content, find the first natural textual occurrence of *any one* keyword from this list. When found, format that specific keyword you've chosen exactly as: <a href=\"%s\" target=\"_blank\"><strong>[The Chosen Related Keyword from your list]</strong></a>. Only link the first related keyword you encounter from the list.

Content Structure (use HTML tags):

<h2>Introduction</h2>
<p>Start with an intriguing question that captures the reader's attention immediately. Ensure the question is relevant to the destination/topic, challenges common perceptions, and evokes curiosity.</p>
<p>Seamlessly incorporate the focus keyword within the first 100 words.</p>

<h2>Destination Overview</h2>
<p>Provide essential contextual information (location, size, population if relevant). Include brief historical or cultural significance. Mention the destination's unique appeal or character. Address practical considerations (language, currency, visa requirements). Share best times to visit with seasonal considerations.</p>

<h2>Getting There & Around</h2>
<p>Detail transportation options to reach the destination. Explain local transportation systems and options. Include approximate costs and time estimates. Offer practical tips for navigating efficiently. Suggest transportation apps or services specific to the region.</p>

<h2>Where to Stay</h2>
<p>Cover 3-4 distinct areas/neighborhoods with individual descriptions. For each area, include character and atmosphere, suitable traveler types (families, solo travelers, budget, luxury), proximity to attractions, and price range expectations. Recommend specific accommodation options across budget ranges. Include insider tips for booking accommodations in this destination.</p>

<h2>Must-See Attractions</h2>
<p>List 5-7 essential sights or experiences. For each attraction, include why it's significant, best time to visit, entry fees and hours, how much time to allocate, photography tips, and insider advice to enhance the experience.</p>

<h2>Off the Beaten Path</h2>
<p>Feature 3-5 lesser-known attractions or experiences. Explain why these alternatives are worth visiting. Include how to access these places and any special considerations. Share personal stories or local insights about these hidden gems.</p>

<h2>Food & Dining Experiences</h2>
<p>Highlight must-try local dishes and beverages. Recommend specific eateries across different price points. Include food markets, cooking classes, or food tours. Share dining etiquette specific to the destination. Suggest meal budgeting information.</p>

<h2>Cultural Experiences & Activities</h2>
<p>Detail immersive cultural activities (festivals, workshops, tours). Provide options for different interests (adventure, history, arts). Include interactive experiences that connect travelers with locals. Suggest booking information and approximate costs.</p>

<h2>Practical Tips</h2>
<p>Share 7-10 actionable tips specific to this destination covering safety considerations, packing recommendations, etiquette and cultural sensitivities, money-saving strategies, communication advice, photography guidance, and avoiding tourist traps or scams.</p>

<h2>Sample Itinerary</h2>
<p>Provide a day-by-day itinerary for the optimal visit duration. Balance popular attractions with hidden gems. Include meal suggestions and timing considerations. Offer alternative options for different interests or weather conditions. Make it adaptable for different travel paces.</p>

<h2>Budgeting Guide</h2>
<p>Break down expected costs for accommodations (budget, mid-range, luxury), meals and drinks, attractions and activities, local transportation, and shopping and souvenirs. Include money-saving tips specific to this destination. Suggest overall budget ranges for different travel styles.</p>

<h2>Best Time to Visit</h2>
<p>Detail seasonal variations and their impact on weather conditions, crowd levels, price fluctuations, special events or festivals, and activity availability. Recommend optimal months for specific experiences. Include shoulder season advantages.</p>

<h2>What to Avoid</h2>
<p>Highlight common mistakes travelers make at this destination. Identify tourist traps that aren't worth the time or money. Mention safety concerns or scams specific to the region. Suggest better alternatives to overrated experiences. Include advice from locals or experienced travelers.</p>

<h2>Sustainability Considerations</h2>
<p>Provide tips for responsible tourism at this destination. Highlight eco-friendly accommodations or tour operators. Suggest ways to minimize environmental impact. Include cultural sensitivity advice. Mention local conservation efforts travelers can support.</p>

<h2>Conclusion</h2>
<p>Summarize the destination's unique appeal in 75-100 words. Reinforce why it's worth visiting and what makes it special. Include a personal reflection or final insider tip. End with an engaging call-to-action: invite comments, questions, or social sharing.</p>

<h2>FAQs</h2>
<p>Create 5-7 common questions travelers have about this destination. Provide comprehensive, helpful answers. Include questions about safety, costs, language, family-friendliness, etc. Address concerns that might prevent someone from visiting.</p>

IMPORTANT: Please ensure you complete ALL requested sections of the article as outlined above, from the introduction to the FAQs. Strive to meet the target word count by providing thorough information in each section to deliver a complete and valuable post.
";

    $prompt = sprintf(
        $base_prompt,
        $post_title,         // 1st %s: Blog Post Title
        $focus_keyword,      // 2nd %s: Focus Keyword (definition)
        $related_keywords,   // 3rd %s: Related keywords (definition)
        $focus_keyword,      // 4th %s: "The Focus Keyword for this article is '%s'"
        $internal_link,      // 5th %s: "The Internal Link URL is '%s'"
        $internal_link,      // 6th %s: href for focus keyword link
        $focus_keyword,      // 7th %s: text for focus keyword link
        $related_keywords,   // 8th %s: "The list of Related Keywords for this article is: '%s'"
        $external_link,      // 9th %s: "The External Link URL is '%s'"
        $external_link       // 10th %s: href for related keyword link
    );

    $api_url = 'https://openrouter.ai/api/v1/chat/completions';
    $request_args = [
        'method'  => 'POST',
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
            'HTTP-Referer'  => get_site_url(),
            'X-Title'       => get_bloginfo('name')
        ],
        'body'    => json_encode([
            'model'    => $selected_model,
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => 3800,
            'temperature' => 0.6,
        ]),
        'timeout' => 120,
    ];

    $response = wp_remote_post( $api_url, $request_args );

    if ( is_wp_error( $response ) ) {
        return [
            'success' => false,
            'post_id' => null,
            'message' => __( 'Error: API request failed. ', 'travel-genie-wp' ) . $response->get_error_message(),
            'content' => null
        ];
    }

    $body = wp_remote_retrieve_body( $response );
    $data = json_decode( $body, true );

    if ( ! $data || ! isset( $data['choices'][0]['message']['content'] ) ) {
        $error_message = isset($data['error']['message']) ? $data['error']['message'] : __( 'Invalid API response or no content received.', 'travel-genie-wp' );
        return [
            'success' => false,
            'post_id' => null,
            'message' => __( 'Error: ', 'travel-genie-wp' ) . $error_message,
            'content' => null
        ];
    }

    $generated_content = $data['choices'][0]['message']['content'];

    // Sanitize the HTML content received from AI
    $content = travel_generator_sanitize_content( $generated_content ); 

    // Generate and insert additional images into the content if Fal AI is configured and selected
    $options = get_option( 'travel_generator_settings' );
    $fal_api_key_present = !empty($options['fal_ai_api_key']);
    $focus_keyword_present = !empty($focus_keyword);
    $can_generate_fal_images = $fal_api_key_present && $focus_keyword_present;

    if ( $can_generate_fal_images ) {
        // 1. Destination Image
        if ( $generate_destination_image ) {
            $destination_image_prompt = "beautiful scenic view of " . $focus_keyword . " destination";
            $destination_image_alt = $focus_keyword . " destination";
            $destination_image_id = travel_generator_generate_and_upload_fal_image( $destination_image_prompt, $post_title . ' - Destination', $destination_image_alt );
            if ( $destination_image_id && !is_wp_error($destination_image_id) ) {
                $destination_image_url = wp_get_attachment_url( $destination_image_id );
                if ($destination_image_url) {
                    $destination_img_html = '<figure class="wp-block-image size-large"><img src="' . esc_url($destination_image_url) . '" alt="' . esc_attr($destination_image_alt) . '"/></figure>';
                    // Inject after <h2>Destination Overview</h2>
                    $content = preg_replace( '/(<h2[^>]*>\s*Destination Overview\s*<\/h2>)/i', '$1' . "\n" . $destination_img_html, $content, 1 );
                    error_log("Fal AI: Inserted destination image for post being created with title: " . $post_title);
                }
            }
        }

        // 2. Activities Image
        if ( $generate_activities_image ) {
            $activities_image_prompt = "people enjoying activities and experiences in " . $focus_keyword;
            $activities_image_alt = $focus_keyword . " activities";
            $activities_image_id = travel_generator_generate_and_upload_fal_image( $activities_image_prompt, $post_title . ' - Activities', $activities_image_alt );
            if ( $activities_image_id && !is_wp_error($activities_image_id) ) {
                $activities_image_url = wp_get_attachment_url( $activities_image_id );
                if ($activities_image_url) {
                    $activities_img_html = '<figure class="wp-block-image size-large"><img src="' . esc_url($activities_image_url) . '" alt="' . esc_attr($activities_image_alt) . '"/></figure>';
                    // Inject after <h2>Cultural Experiences & Activities</h2>
                    $content = preg_replace( '/(<h2[^>]*>\s*Cultural Experiences & Activities\s*<\/h2>)/i', '$1' . "\n" . $activities_img_html, $content, 1 );
                    error_log("Fal AI: Inserted activities image for post being created with title: " . $post_title);
                }
            }
        }
    }

    // Create the post data
    $post_data = [
        'post_title'   => wp_strip_all_tags( $post_title ),
        'post_content' => $content,
        'post_status'  => 'draft',
        'post_author'  => get_current_user_id(),
        'post_type'    => 'post',
    ];

    $new_post_id = wp_insert_post( $post_data );

    if ( is_wp_error( $new_post_id ) ) {
        return [
            'success' => false,
            'post_id' => null,
            'message' => __( 'Error creating post: ', 'travel-genie-wp' ) . $new_post_id->get_error_message(),
            'content' => $generated_content
        ];
    }

    // If post created successfully, try to set Fal AI generated featured image
    $fal_message_addon = '';

    if ( $generate_featured_image ) {
        if ( !empty($options['fal_ai_api_key']) && !empty($focus_keyword) ) {
            $fal_image_prompt = "stunning travel destination photo of " . $focus_keyword;
            $featured_image_id = travel_generator_generate_and_upload_fal_image( $fal_image_prompt, $post_title, $focus_keyword );

            if ( $featured_image_id ) {
                set_post_thumbnail( $new_post_id, $featured_image_id );
                $fal_message_addon = ' ' . __( 'Featured image generated and set via Fal AI.', 'travel-genie-wp' );
                error_log("Fal AI: Successfully generated and set featured image for post {$new_post_id}. Attachment ID: {$featured_image_id}");
            } else {
                $fal_message_addon = ' ' . __( 'Featured image generation/setting failed via Fal AI.', 'travel-genie-wp' );
                error_log('Fal AI: Failed to generate/set featured image for post ID: ' . $new_post_id);
            }
        } else if (empty($options['fal_ai_api_key'])) {
            $fal_message_addon = ' ' . __( 'Featured image generation skipped (Fal AI API key not set).', 'travel-genie-wp' );
            error_log('Fal AI: Featured image generation skipped (Fal AI API key not set) for post ID: ' . $new_post_id);
        } else {
            $fal_message_addon = ' ' . __( 'Featured image generation skipped (Focus keyword not provided).', 'travel-genie-wp' );
            error_log('Fal AI: Featured image generation skipped (Focus keyword not provided) for post ID: ' . $new_post_id);
        }
    } else {
        $fal_message_addon = ' ' . __( 'Featured image generation skipped by user.', 'travel-genie-wp' );
        error_log('Fal AI: Featured image generation skipped by user for post ID: ' . $new_post_id);
    }

    // Save focus keyword and related keywords as post meta
    if ( ! empty( $focus_keyword ) ) {
        update_post_meta( $new_post_id, 'travel_generator_focus_keyword', sanitize_text_field( $focus_keyword ) );
    }
    if ( ! empty( $related_keywords ) ) {
        update_post_meta( $new_post_id, 'travel_generator_related_keywords', sanitize_text_field( $related_keywords ) );
    }
    // Add a meta field to identify this as an AI travel article
    update_post_meta( $new_post_id, '_travel_generator_ai_article', true );

    return [
        'success' => true,
        'post_id' => $new_post_id,
        'message' => '<span class="dashicons dashicons-yes-alt"></span> ' . __( 'Travel article draft created successfully.', 'travel-genie-wp' ) . $fal_message_addon,
        'content' => $content
    ];
}

/**
 * Sanitize the content received from the AI.
 */
function travel_generator_sanitize_content( $content ) {
    $allowed_html = [
        'h1'     => [],
        'h2'     => [],
        'h3'     => [],
        'h4'     => [],
        'ul'     => [],
        'ol'     => [],
        'li'     => [],
        'p'      => [],
        'a'      => [ 'href' => true, 'target' => true ],
        'strong' => [],
        'em'     => [],
        'br'     => [],
        'figure' => [ 'class' => true ],
        'img'    => [ 'src' => true, 'alt' => true, 'class' => true ],
    ];
    return wp_kses( $content, $allowed_html );
}


/**
 * Render the Help admin page.
 */
function travel_generator_page_help_html() {
    // Ensure the user has the 'manage_options' capability to access this page.
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( __( 'You do not have sufficient permissions to access this page.', 'travel-genie-wp' ) );
    }

    ?>
    <div class="wrap travel-generator-help-page">
        <h1><?php _e('Help & Support', 'travel-genie-wp'); ?></h1>

        <p><?php _e('Click on a section below to expand it and find links to relevant documentation or support information.', 'travel-genie-wp'); ?></p>

        <div id="travel-generator-help-accordion">
            <div class="travel-generator-help-section">
                <h3 class="travel-generator-help-section-title">
                    <?php _e('Getting Started', 'travel-genie-wp'); ?>
                    <span class="dashicons dashicons-arrow-down-alt2 toggle-icon"></span>
                </h3>
                <div class="travel-generator-help-section-content">
                    <p><?php _e('TunisiaExplorer is a platform dedicated to smart tools and content automation for travel bloggers and creators. It offers comprehensive resources, tools, and guidance focused on travel content creation, SEO optimization, and destination marketing strategies. TunisiaExplorer\'s mission is to provide practical, hands-on solutions that empower travel content creators to build and scale successful travel blogs and websites.', 'travel-genie-wp'); ?></p>
                    <p><?php _e('Through its focus on actionable tools and resources, TunisiaExplorer bridges the gap between travel inspiration and professional content creation, enabling creators to transform their travel experiences into engaging, SEO-optimized content.', 'travel-genie-wp'); ?></p>
                </div>
            </div>

            <div class="travel-generator-help-section">
                <h3 class="travel-generator-help-section-title">
                    <?php _e('Basic Troubleshooting Steps', 'travel-genie-wp'); ?>
                    <span class="dashicons dashicons-arrow-down-alt2 toggle-icon"></span>
                </h3>
                <div class="travel-generator-help-section-content">
                    <p><?php _e('If the plugin is not working as expected, try these common fixes:', 'travel-genie-wp'); ?></p>
                    <ul>
                        <li><?php _e('<strong>API Key:</strong> Ensure your OpenRouter and Fal.ai API keys are correctly entered in the plugin settings and are active.', 'travel-genie-wp'); ?></li>
                        <li><?php _e('<strong>Permissions:</strong> Check if your user role has the necessary permissions to use the plugin features.', 'travel-genie-wp'); ?></li>
                        <li><?php _e('<strong>Network Issues:</strong> Verify your internet connection. The plugin needs to connect to external APIs.', 'travel-genie-wp'); ?></li>
                        <li><?php _e('<strong>Plugin Conflicts:</strong> Try deactivating other plugins temporarily to see if there is a conflict.', 'travel-genie-wp'); ?></li>
                        <li><?php _e('<strong>Theme Conflicts:</strong> Switch to a default WordPress theme (like Twenty Twenty-One) to check for theme-related issues.', 'travel-genie-wp'); ?></li>
                    </ul>
                </div>
            </div>

            <div class="travel-generator-help-section">
                <h3 class="travel-generator-help-section-title">
                    <?php _e('Common Problems and Solutions', 'travel-genie-wp'); ?>
                    <span class="dashicons dashicons-arrow-down-alt2 toggle-icon"></span>
                </h3>
                <div class="travel-generator-help-section-content">
                    <p><?php _e('Here are some frequently asked questions:', 'travel-genie-wp'); ?></p>
                    <ul>
                        <li><strong><?php _e('Q1: How do I generate travel images with the plugin?', 'travel-genie-wp'); ?></strong><br><?php _e('A1: After installing the plugin, go to the Travel Generator settings and enter your Fal.ai API key. Then, create a new travel article, fill in the destination details, and click "Generate Images." The plugin will fetch AI-generated images for your destination, activities, and travel experiences.', 'travel-genie-wp'); ?></li>
                        <li><strong><?php _e('Q2: Why aren\'t my travel images appearing?', 'travel-genie-wp'); ?></strong><br><?php _e('A2: Ensure your Fal.ai API key is valid and has sufficient credits. Check your internet connection and verify the image generation settings (image size, style). Also, confirm that your WordPress site can connect to external APIs.', 'travel-genie-wp'); ?></li>
                        <li><strong><?php _e('Q3: Can I customize the travel image styles?', 'travel-genie-wp'); ?></strong><br><?php _e('A3: Yes! The plugin allows you to choose different image styles like "realistic," "artistic," or "scenic." You can adjust these options in the settings before generating the images.', 'travel-genie-wp'); ?></li>
                        <li><strong><?php _e('Q4: Where are the generated images saved?', 'travel-genie-wp'); ?></strong><br><?php _e('A4: Generated images are automatically saved in your WordPress Media Library under the "Uploads" folder, and linked to your travel article post.', 'travel-genie-wp'); ?></li>
                        <li><strong><?php _e('Q5: What if I need support or have issues?', 'travel-genie-wp'); ?></strong><br><?php _e('A5: For plugin support, visit the "Help & Support" section in the plugin or contact the developer through the WordPress.org plugin page. For general travel content creation tips, check out resources on TunisiaExplorer\'s website at www.tunisiaexplorer.com.', 'travel-genie-wp'); ?></li>
                    </ul>
                </div>
            </div>

            <div class="travel-generator-help-section">
                <h3 class="travel-generator-help-section-title">
                    <?php _e('Compatibility Issues', 'travel-genie-wp'); ?>
                    <span class="dashicons dashicons-arrow-down-alt2 toggle-icon"></span>
                </h3>
                <div class="travel-generator-help-section-content">
                    <p><?php _e('For optimal performance, please ensure your environment meets the following requirements (referencing TunisiaExplorer\'s technical recommendations where applicable):', 'travel-genie-wp'); ?></p>
                    <ul>
                        <li><?php _e('<strong>PHP Version:</strong> 7.4 or higher recommended.', 'travel-genie-wp'); ?></li>
                        <li><?php _e('<strong>WordPress Version:</strong> 5.5 or higher recommended.', 'travel-genie-wp'); ?></li>
                        <li><?php _e('<strong>Hosting:</strong> Ensure your hosting allows outgoing cURL requests for API communication. Sufficient memory allocation is also advised for processing travel articles and images.', 'travel-genie-wp'); ?></li>
                        <li><?php _e('<strong>Known Conflicts:</strong> [List any known plugin/theme conflicts if identified. Currently, none are pre-defined.]', 'travel-genie-wp'); ?></li>
                    </ul>
                </div>
            </div>

            <div class="travel-generator-help-section">
                <h3 class="travel-generator-help-section-title">
                    <?php _e('Contact Support', 'travel-genie-wp'); ?>
                    <span class="dashicons dashicons-arrow-down-alt2 toggle-icon"></span>
                </h3>
                <div class="travel-generator-help-section-content">
                    <p><?php _e('If you need further assistance, please reach out through the following channels:', 'travel-genie-wp'); ?></p>
                    <ul>
                        <li><?php _e('<strong>Support Page:</strong> <a href="https://www.tunisiaexplorer.com/support" target="_blank" rel="noopener noreferrer">TunisiaExplorer Contact Page</a>', 'travel-genie-wp'); ?></li>
                        <li><?php _e('<strong>Email:</strong> <a href="mailto:info@tunisiaexplorer.com">info@tunisiaexplorer.com</a>', 'travel-genie-wp'); ?></li>
                        <li><?php _e('<strong>Website:</strong> <a href="https://www.tunisiaexplorer.com" target="_blank" rel="noopener noreferrer">TunisiaExplorer.com</a>', 'travel-genie-wp'); ?></li>
                    </ul>
                </div>
            </div>

            <div class="travel-generator-help-section">
                <h3 class="travel-generator-help-section-title">
                    <?php _e('OpenRouter API Documentation', 'travel-genie-wp'); ?>
                    <span class="dashicons dashicons-arrow-down-alt2 toggle-icon"></span>
                </h3>
                <div class="travel-generator-help-section-content">
                    <p><?php _e('OpenRouter provides access to a wide variety of LLMs. Their documentation covers API keys, model selection, and usage.', 'travel-genie-wp'); ?></p>
                    <p><a href="https://openrouter.ai/docs/quickstart" target="_blank" rel="noopener noreferrer" class="button button-secondary"><?php _e('View OpenRouter Quickstart', 'travel-genie-wp'); ?></a></p>
                    <p><a href="https://openrouter.ai/docs" target="_blank" rel="noopener noreferrer" class="button button-secondary"><?php _e('View Full OpenRouter Docs', 'travel-genie-wp'); ?></a></p>
                </div>
            </div>

            <div class="travel-generator-help-section">
                <h3 class="travel-generator-help-section-title">
                    <?php _e('Fal.ai API Documentation', 'travel-genie-wp'); ?>
                    <span class="dashicons dashicons-arrow-down-alt2 toggle-icon"></span>
                </h3>
                <div class="travel-generator-help-section-content">
                    <p><?php _e('Fal.ai is used for image generation. Their documentation provides information on API usage, available models, and managing credentials.', 'travel-genie-wp'); ?></p>
                    <p><a href="https://docs.fal.ai/" target="_blank" rel="noopener noreferrer" class="button button-secondary"><?php _e('View Fal.ai Documentation', 'travel-genie-wp'); ?></a></p>
                </div>
            </div>
        </div>
    </div>

    <style>
        .travel-generator-help-page #travel-generator-help-accordion {
            margin-top: 20px;
        }
        .travel-generator-help-section {
            border: 1px solid #ccd0d4;
            margin-bottom: -1px;
        }
        .travel-generator-help-section:first-child {
            border-top-left-radius: 3px;
            border-top-right-radius: 3px;
        }
        .travel-generator-help-section:last-child {
            border-bottom-left-radius: 3px;
            border-bottom-right-radius: 3px;
            margin-bottom: 0;
        }
        .travel-generator-help-section-title {
            background-color: #f6f7f7; 
            padding: 10px 15px;
            margin: 0;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
            border-bottom: 1px solid #ccd0d4;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .travel-generator-help-section:last-child .travel-generator-help-section-title {
             border-bottom: none;
        }
        .travel-generator-help-section-title.active {
            border-bottom-color: #ccd0d4;
        }
         .travel-generator-help-section-title.active + .travel-generator-help-section-content {
            border-top: 1px solid #ccd0d4;
        }
        .travel-generator-help-section-title .toggle-icon {
            transition: transform 0.2s ease-in-out;
            font-size: 20px;
        }
        .travel-generator-help-section-title.active .toggle-icon {
            transform: rotate(-180deg);
        }
        .travel-generator-help-section-content {
            padding: 15px;
            background-color: #fff;
            display: none;
        }
        .travel-generator-help-section-content p {
            margin-top: 0;
            margin-bottom: 10px;
        }
        .travel-generator-help-section-content p:last-child {
            margin-bottom: 0;
        }
        .travel-generator-help-section-content .button-secondary {
            margin-right: 10px;
        }
    </style>

    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#travel-generator-help-accordion .travel-generator-help-section-title').click(function() {
                var $content = $(this).next('.travel-generator-help-section-content');
                var $icon = $(this).find('.toggle-icon');

                // Toggle current section
                $content.slideToggle(200);
                $(this).toggleClass('active');
            });
        });
    </script>
    <?php
}

/**
 * Render the shortcode.
 *
 * @param array $atts Shortcode attributes.
 * @return string HTML output for the shortcode.
 */
function travel_generator_render_shortcode( $atts ) {
    $atts = shortcode_atts([
        'post_title'      => '',
        'focus_keyword'   => '',
        'related_keywords' => '',
        'internal_link'   => '',
        'external_link'   => '',
    ], $atts, 'travel_generator' );

    return travel_generator_generate_article_post( $atts );
}

/**
 * Register Gutenberg block.
 */
function travel_generator_register_block() {
    if ( ! function_exists( 'register_block_type' ) ) {
        return; // Gutenberg is not active.
    }

    // Path to the block.json file, assuming it's in a 'build' directory
    $block_json_path = TRAVEL_GENERATOR_PATH . 'build/block.json'; 

    if ( file_exists( $block_json_path ) ) {
        register_block_type( $block_json_path, [
            'render_callback' => 'travel_generator_render_block',
        ]);
    }
}

/**
 * Render callback for the Gutenberg block.
 *
 * @param array $attributes Block attributes.
 * @return string HTML output for the block.
 */
function travel_generator_render_block( $attributes ) {
    $args = [
        'post_title'      => isset( $attributes['postTitle'] ) ? $attributes['postTitle'] : '',
        'focus_keyword'   => isset( $attributes['focusKeyword'] ) ? $attributes['focusKeyword'] : '',
        'related_keywords' => isset( $attributes['relatedKeywords'] ) ? $attributes['relatedKeywords'] : '',
        'internal_link'   => isset( $attributes['internalLink'] ) ? $attributes['internalLink'] : '',
        'external_link'   => isset( $attributes['externalLink'] ) ? $attributes['externalLink'] : '',
    ];
    return travel_generator_generate_article_post( $args );
}

/**
 * Enqueue scripts and styles for the frontend.
 */
function travel_generator_enqueue_frontend_assets() {
    if ( is_singular() ) {
        global $post;
        if ( $post && has_shortcode( $post->post_content, 'travel_generator' ) ) {
            wp_enqueue_style( 'wp-block-travel-generator-block-style' );
        }
    }
}

// Filter the admin footer text for plugin pages
function travel_genie_override_admin_footer_text($footer_text) {
    $screen = get_current_screen();
    if ( ! $screen ) {
        return $footer_text;
    }

    $plugin_pages_bases = [
        'toplevel_page_travel-generator-main',
        'travel-generator_page_travel-generator-view-generated',
        'travel-generator_page_travel-generator-settings',
        'travel-generator_page_travel-generator-help'
    ];

    if (in_array($screen->base, $plugin_pages_bases)) {
        return 'Made with <span style="color: #ff0000;">♥</span> by TunisiaExplorer Team';
    }
    return $footer_text;
}
add_filter( 'admin_footer_text', 'travel_genie_override_admin_footer_text', 11 );

add_action( 'wp_enqueue_scripts', 'travel_generator_enqueue_frontend_assets' );

